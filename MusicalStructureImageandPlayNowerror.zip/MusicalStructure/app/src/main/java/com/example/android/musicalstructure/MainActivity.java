package com.example.android.musicalstructure;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Find the View that shows the music library category

        TextView musicLibrary = (TextView) findViewById(R.id.music_library);
        // Set a click listener on that View
        musicLibrary.setOnClickListener(new View.OnClickListener() {
            // Create a new intent to open the (@link NumbersActivity).
            @Override
            public void onClick(View view) {
                Intent musicLibraryIntent = new Intent(MainActivity.this, MusicLibraryActivity.class);
                startActivity(musicLibraryIntent);
            }

        });

        //Find the View that shows the now playing category

        TextView nowPlaying = (TextView) findViewById(R.id.now_playing);
        // Set a click listener on that View
        nowPlaying.setOnClickListener(new View.OnClickListener() {
            // Create a new intent to open the (@link NumbersActivity).
            @Override
            public void onClick(View view) {
                Intent nowPlayingIntent = new Intent(MainActivity.this, NowPlayingActivity.class);
                startActivity(nowPlayingIntent);
            }

        });

        //Find the View that shows the wham playlist category

        TextView whamPlaylist = (TextView) findViewById(R.id.wham_playlist);
        // Set a click listener on that View
        whamPlaylist.setOnClickListener(new View.OnClickListener() {
            // Create a new intent to open the (@link NumbersActivity).
            @Override
            public void onClick(View view) {
                Intent whamPlaylistIntent = new Intent(MainActivity.this, WhamPlaylistActivity.class);
                startActivity(whamPlaylistIntent);
            }

        });

        //Find the View that shows the four tops playlist category

        TextView fourTopsPlaylist = (TextView) findViewById(R.id.four_tops_playlist);
        // Set a click listener on that View
        fourTopsPlaylist.setOnClickListener(new View.OnClickListener() {
            // Create a new intent to open the (@link NumbersActivity).
            @Override
            public void onClick(View view) {
                Intent fourTopsPlaylistIntent = new Intent(MainActivity.this, FourTopsPlaylistActivity.class);
                startActivity(fourTopsPlaylistIntent);
            }

        });


    }
}


