package com.example.android.musicalstructure;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MusicLibraryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_list);


        //Create a list of songs
        ArrayList<Song> songs = new ArrayList<Song> ();
        songs.add(new Song("Freedom", "Wham"));
        songs.add(new Song("I'm Your Man", "Wham"));
        songs.add(new Song("Wake Me Up Before You Go Go", "Wham"));
        songs.add(new Song("Last Christmas", "Wham"));
        songs.add(new Song("Careless Whisper", "Wham"));
        songs.add(new Song("Club Tropicana", "Wham"));
        songs.add(new Song("The Edge Of Heaven", "Wham"));
        songs.add(new Song("A Different Corner", "Wham"));
        songs.add(new Song("Bad Boys", "Wham"));
        songs.add(new Song("Everything She Wants", "Wham"));
        songs.add(new Song("It's The Same Old Song", "The Four Tops"));
        songs.add(new Song("Reach Out I'll Be There", "The Four Tops"));
        songs.add(new Song("Standing In The Shadows Of Love", "The Four Tops"));
        songs.add(new Song("I Can't Help Myself", "The Four Tops"));
        songs.add(new Song("Bernadette", "The Four Tops"));
        songs.add(new Song("Walk Away Renee", "The Four Tops"));
        songs.add(new Song("Baby I Need Your Loving", "The Four Tops"));
        songs.add(new Song("Loco In Acapulco", "The Four Tops"));
        songs.add(new Song("Seven Rooms Of Gloom", "The Four Tops"));
        songs.add(new Song("Something About You", "The Four Tops"));

        // Create an {@link ArrayAdapter}, whose data source is a list of Songs. The
        // adapter knows how to create layouts for each item in the list, using the
        // simple_list_item_1.xml layout resource defined in the Android framework.
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single song.


               SongAdapter adapter =
                                new SongAdapter(this, songs);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // song_list.xml file.
        ListView listView = (ListView) findViewById(R.id.list);

        // Make the {@link ListView} use the {@link SongAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Song} in the list.
        listView.setAdapter(adapter);


    Button playNowButton = findViewById(R.id.play_now_button);
        playNowButton.setOnClickListener(new View.OnClickListener(){
        public void onClick(View view) {
            // Create a new intent to open the {@link NowPlayingActivity}
            Intent NowPlayingIntent = new Intent(MusicLibraryActivity.this, NowPlayingActivity.class);
            startActivity(NowPlayingIntent);
        }

    });
}}












