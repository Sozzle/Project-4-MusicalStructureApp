package com.example.android.musicalstructure;

/**
 * Created by John on 26/04/2018.
 */

public class Song {




    //Create a new Song object

    //@param Song is the name of the Song

    //Create a new Song object


    private String mSong;

    //Create a new Artist object

    //@param Artist is the name of the Artist

    private String mArtist;


    public Song(String Song, String Artist) {
        mSong = Song;
        mArtist = Artist;
    }

    /**
     * Get the name of the song.
     */
    public String getSong() {
        return mSong;
    }

    /**
     * Get the artist of the song.
     */
    public String getArtist() {
        return mArtist;
    }

}


